# # A1B1.py for IDSA A1
# # FINISHED by: <Yip Lai Chi>, <20219883>

class AList: # defining a class of FIXEDSIZE-Array-List

    def __init__(self, inSize=3): # constructor, default size=3
        self.pList=[None]*inSize  # new a Python List to hold data
        self.last = 0             # The position of the last element
        self.capacity = inSize  # The current capacity of the list

        #######STUDENT's WORK#######
        # simple comment HERE
        def insertL(self, elt, pos): # Insert element, pos start from 1
            if self.isFullL():
                return
            if pos > self.last + 1:
                pos = self.last + 1
            for i in range(self.last, pos-1, -1):
                self.pList[i+1] = self.pList[i]
            self.pList[pos-1] = elt
            self.last += 1

        # simple comment HERE
        def appendL(self, elt):
            if self.isFullL():
                return
            self.pList[self.last] = elt
            self.last += 1

        # simple comment HERE
        def searchFirstL(self, elt):
            if self.isEmpty():
                return -1
            for i in range(self.last):
                if self.pList[i] == elt:
                    return i+1
            return -1

        # simple comment HERE
        def clearL(self):
            self.pList = [None] * self.capacity
            self.last = 0

        ##### END of STUDENT's WORK#######

        def isEmpty(self): # check if the list is empty or not
            return self.sizeL()==0

        def isFullL(self): # check if the list is full or not
            return self.sizeL()==self.capacity

        def sizeL(self): # Return size of List (number of elements)
            return self.last

        def display(self):
            print(f'>>>AList Display(Head/Left), size/last<{self.last}>,', f'capacity<{self.capacity}>:')