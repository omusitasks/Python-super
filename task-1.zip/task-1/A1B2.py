# # # A1B1.py for IDSA A1
# # # FINISHED by: <Yip Lai Chi>, <20219883>

class DLNode: # modelling a node with Doubly-Linked-List 
    def _init_(self, inValue=None, inPrev=None, inNext=None): # constructor
        self.value = inValue # the node data value, default None 
        self.prevN = inPrev # the previous node, default None
        self.nextN = inNext # the next node, default None

class DLList: # defining a class of Doubly-Linked-List 
    
    def _init_(self): # GIVEN: constructor 
        self.headN = None # the head Node 
        self.tailN = None # the tail Node

        ##STUDNET'S WORK #####
        # # #simple comment HERE
        def getNextFwDL(self, refElt): # Get & return (without remove) next element of reference refElt, in forward order 
            currNode = self.headN
            if currNode.value == refElt:
                currNode = currNode.nextN
                if currNode == None:
                    return None
                else:
                    return currNode.value
            else:
                while currNode.nextN != None:
                    if currNode.value == refElt:
                        currNode = currNode.nextN
                        return currNode.value
                    else:
                        currNode = currNode.nextN
            return None

        # simple comment HERE
        def getPrevBwDL(self, refElt): # Get & return (without remove) previous element of reference refElt, in backward order
            currNode = self.tailN
            if currNode.value == refElt:
                currNode = currNode.prevN
                if currNode == None:
                    return None
                else:
                    return currNode.value
            else:
                while currNode.prevN != None:
                    if currNode.value == refElt:
                        currNode = currNode.prevN
                        return currNode.value
                    else:
                        currNode = currNode.prevN
            return None

        # simple comment HERE
        def removeNextFwDL(self, refElt): # REMOVE & return next element of reference refElt, in forward order 
            currNode = self.headN
            if currNode.value == refElt:
                currNode = currNode.nextN
                if currNode == None:
                    return None
                else:
                    removedNode = currNode
                    nextNode = currNode.nextN
                    currNode.prevN.nextN = nextNode
                    nextNode.prevN = currNode.prevN
                    return removedNode.value
            else:
                while currNode.nextN != None:
                    if currNode.value == refElt:
                        currNode = currNode.nextN
                        removedNode = currNode
                        nextNode = currNode.nextN
                        currNode.prevN.nextN = nextNode
                        nextNode.prevN = currNode.prevN
                        return removedNode.value
                    else:
                        currNode = currNode.nextN
            return None

        # simple comment HERE
        def appendDL(self, elt): # GIVEN: append/insert a new node value, as the new tail
            if self.headN==None: # case of empty DLL 
                newTailN = DLNode(elt) # create new Node 
                self.headN = newTailN # link new (Tail) Node 
                self.tailN = self.headN
            else:
                newTailN = DLNode(elt, self.tailN) # create a new (Tail) Node, set its previous node as the current Tail 
                self.tailN.nextN = newTailN # current Tail. links next
        ####### END of STUDNET's WORK  #####