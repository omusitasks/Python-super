# === A1B1, MA1B1 Main Testing Program, by <Yip Lai Chi>, <20219883>  ===

# Main Testing Program

from A1B1 import AList

def main():
    print("=== A1B1, Fixed-Sized ArrayList, by <Student NAME><Student ID> ===\n")
    myL = AList(5)
    print(f"--- 0. new AL <CHECK> isFullL()?:{myL.isFullL()}, isEmptyL()?:{myL.isEmptyL()}")
    myL.displayL()
    print(f"--- 1. insertL <ABQCP>-R?")
    myL.insertL('A', 1); myL.insertL('B', 2); myL.insert('C', 3); 
    myL.insertL('P', 4); myL.insertL('Q', 3); myL.insertL('R', 2); 
    myL.displayL()
    
    myL.removeL (4); myL.removeL (4);
    print("\n---2. appendL: <ABQ,QA>-H? ") 
    myL.appendL('Q'); myL.appendL ('A'); myL.appendL('H'); 
    myL.displayL() 
    print("\n 3. <CHECK> search FirstL('Q'), pos:{myL.searchFirstL('Q')}")
    print("\n--- 3. removeL (myL.searchFirstL ('A')), elt:{myL.removeL (myL.searchFirstL('A'))}")
    myL.displayL()
    print(f"- <CHECK> searchFirstL('Q'), pos:{myL.searchFirstL('Q')}")
    print(f"--------- <CHECK> searchFirstL('H'), pos:{myL.searchFirstL('H')}")
    print (f"------<CHECK> searchFirstL('QA'), pos:{myL.searchFirstL('QA')}")
    print("\n=== Program ends ===\n")

main()