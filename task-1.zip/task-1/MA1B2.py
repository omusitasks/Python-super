# === A1B1, MA1B2 Main Testing Program, by <Yip Lai Chi>, <20219883>  ===

# Main Testing Program

from A1B2 import DLList

def main():
    print("====== A1B2, DLList program, by <Student NAME><Student ID>===")
    myL = DLList()
    myL.appendDL(20); myL.appendDL (30); myL.appendDL(40)
    myL.appendDL(50); myL.appendDL(60); myL.appendDL(70)
    print("\n--- 1. List with Insert items <20,30,40,50,60,70> ---")
    
    myL.displayDL()
    myL.displayBwDL()

    print(f" --- ------<CHECK> getNextFwDL(50), elt:{myL.getNextFwDL(50)}")
    print(f" -- <CHECK> getPrevBwDL(60), elt:{myL.getPrevBwDL(60)}")
    print(f"\n 2. <CHECK> removeNextFwDL (30), elt:{myL.removeNextFwDL(30)}")
    myL.displayDL()
    myL.displayBwDL()
    
    print("\n=== Program ends ===\n")

main() 